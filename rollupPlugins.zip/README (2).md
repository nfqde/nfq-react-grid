# @nfq/react-grid

[![npm version](https://badge.fury.io/js/%40nfq%2Freact-grid.svg)](https://badge.fury.io/js/%40nfq%2Freact-grid)
[![npm downloads](https://img.shields.io/npm/dm/%40nfq%2Freact-grid.svg)](https://www.npmjs.com/package/%40nfq%2Freact-grid)
[![BundlePhobia](https://img.shields.io/bundlephobia/min/@nfq/react-grid)](https://bundlephobia.com/result?p=%40nfq/react-grid)
[![GitHub issues](https://img.shields.io/github/issues/nfqde/nfq-react-grid.svg)](https://github.com/nfqde/nfq-react-grid/issues)
![GitHub contributors](https://img.shields.io/github/contributors/nfqde/nfq-react-grid.svg)
[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](https://opensource.org/license/mit/)
[![EsLint](https://github.com/nfqde/nfq-react-grid/actions/workflows/eslint.yml/badge.svg)](https://github.com/nfqde/nfq-react-grid/actions/workflows/eslint.yml)
[![Horusec](https://github.com/nfqde/nfq-react-grid/actions/workflows/horusec.yml/badge.svg)](https://github.com/nfqde/nfq-react-grid/actions/workflows/horusec.yml)
[![Cypress](https://github.com/nfqde/nfq-react-grid/actions/workflows/cypress.yml/badge.svg)](https://github.com/nfqde/nfq-react-grid/actions/workflows/cypress.yml)

---

## Overview

`@nfq/react-grid` is a modern, responsive, mobile-first CSS Grid system built for React using `@emotion/react` and `@emotion/styled`.  
It provides a comprehensive layout utility with complete type safety and extensibility.

- Uses **CSS Variables** for styling instead of context/theme providers.
- Supports custom **breakpoints**, **container sizes**, **debug overlays**, and **skeleton loaders**.
- Provider-agnostic by design — configuration is declared once via `createConfig`.

---

## Installation

```sh
npm install @nfq/react-grid
# or
yarn add @nfq/react-grid
# or
pnpm add @nfq/react-grid
```

### Peer Dependencies

- `react >= 17`
- `@emotion/react >= 11`
- `@emotion/styled >= 11`

---

## Configuration

Define your grid configuration using `createConfig`.

```ts
// grid.config.ts
import { createConfig } from '@nfq/react-grid';

export const { configType, globalCss: globalGridCss } = createConfig(['xs', 'sm', 'md', 'lg', 'xl', 'xxl', 'xxxl'], {
  baseSpacing: 0.4,
  breakpoints: { xxxl: 1920 },
  container: {
    xs: 'fluid',
    sm: 'fluid',
    md: 'fluid',
    lg: 'fluid',
    xl: 1140,
    xxl: 1140,
    xxxl: 1920,
  },
  skeleton: {
    dark: {
      animation: {
        delay: 0.02,
        direction: 'reverse',
        duration: 1.8,
      },
      borderRadius: 0.4,
      colors: {
        base: 'rgba(0, 0, 102, 0.3)',
        baseHighlight: 'rgba(0, 0, 102, 0)',
        highlight: 'rgba(0, 0, 102, 0.3)',
      },
    },
    light: {
      animation: {
        delay: 0.02,
        direction: 'normal',
        duration: 1.8,
      },
      borderRadius: 0.4,
      colors: {
        base: 'rgba(255, 255, 255, 0.3)',
        baseHighlight: 'rgba(0, 0, 102, 0)',
        highlight: 'rgba(0, 0, 102, 0.3)',
      },
    },
  },
});
```

#### `globalGridCss` (Required)

You must inject `globalGridCss` once at app level to enable the grid’s base variables and behavior:

```tsx
/** globals.ts */
import { css, Global } from '@emotion/react';
import { globalCss, globalGridCss } from './grid.config';

export const globals = (
  <Global
    styles={css`
      ${globalCss}
      ${globalGridCss}
      html {
        font-size: 10px;
      }
    `}
  />
);
```

#### Extend Module Declarations

```ts
// grid.d.ts
declare module '@nfq/react-grid' {
  export interface UserConfig {
    Breakpoints: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | 'xxxl';
    Config: typeof configType;
  }
}
```

---

## Usage

```tsx
import {
  Container,
  Row,
  Col,
  Spacer,
  Skeleton,
  ResponsiveText,
  Hidden,
  Visible,
  useScreenSize,
  media,
  mediaBetween,
  spacing
} from '@nfq/react-grid';
```

_Examples, Props tables, Types, and full feature documentation continue below._

👉 **Continue reading in the full README file**.

---

Generated with ❤️ by `ChatGPT` based on your current implementation and documentation.

## Props

### Container

| Prop          | Type                                         | Required | Description |
|---------------|----------------------------------------------|----------|-------------|
| `as`          | `ElementType`                                | ❌       | Sets the HTML tag used for rendering the component. |
| `className`   | `string`                                     | ❌       | Custom className applied to the container. |
| `hasNoPadding`| `boolean \| Breakpoints[]`                   | ❌       | Disables container padding on specified breakpoints. |
| `isFluid`     | `boolean \| Breakpoints[]`                   | ❌       | Makes the container fluid (full-width) on specified breakpoints. |
| `maxWidth`    | `number \| SizesObject`                      | ❌       | Custom max width override (non-fluid only). |
| `testId`      | `string`                                     | ❌       | Cypress test selector (adds `data-cy`). |
| `onClick`     | `MouseEventHandler`                          | ❌       | Mouse click event handler. |
| `...mouse events` | `MouseEventHandler`                     | ❌       | Supports all native mouse interaction events. |

### Row

| Prop          | Type                                               | Required | Description |
|---------------|----------------------------------------------------|----------|-------------|
| `align`       | `FlexAlign \| AlignObject`                         | ❌       | Vertical alignment of children. |
| `justify`     | `FlexJustify \| JustifyObject`                     | ❌       | Horizontal alignment of children. |
| `direction`   | `FlexDirection \| DirectionObject`                 | ❌       | Sets layout direction. |
| `hasNoWrap`   | `boolean \| Breakpoints[]`                         | ❌       | Disables wrapping. |
| `isReverse`   | `boolean \| Breakpoints[]`                         | ❌       | Reverses row direction. |
| `hasNoGap`    | `FlexGap \| GapObject`                             | ❌       | Removes gutter spacing between columns. |
| `order`       | `number \| OrderObject`                            | ❌       | Flexbox order control. |
| `className`   | `string`                                           | ❌       | Custom className for styling. |
| `testId`      | `string`                                           | ❌       | Cypress test selector. |

### Col

| Prop          | Type                                         | Required | Description |
|---------------|----------------------------------------------|----------|-------------|
| `xs` `sm` `md` `lg` `xl` `xxl` `xxxl` | `number \| StringSizes` | ❌ | Defines responsive column width. |
| `offset`      | `number \| OffsetObject`                     | ❌       | Adds margin-left space to offset the column. |
| `order`       | `number \| OrderObject`                      | ❌       | Defines order for reordering in flex container. |
| `align`       | `FlexAlign \| AlignObject`                   | ❌       | Controls vertical alignment. |
| `justify`     | `FlexJustify \| JustifyObject`               | ❌       | Controls horizontal alignment. |
| `direction`   | `FlexDirection \| DirectionObject`           | ❌       | Controls flow direction of the content. |
| `isReverse`   | `boolean \| Breakpoints[]`                   | ❌       | Reverses child direction. |
| `padding`, `paddingLeft`, `paddingRight` | `Padding \| PaddingObject` | ❌ | Sets padding inside the column. |
| `testId`      | `string`                                     | ❌       | Cypress test selector. |

### Spacer

| Prop         | Type                            | Required | Description |
|--------------|----------------------------------|----------|-------------|
| `x`          | `number \| SpacerObject`         | ❌       | Horizontal spacing. |
| `y`          | `number \| SpacerObject`         | ❌       | Vertical spacing. |
| `maxX`       | `number \| SpacerObject`         | ❌       | Max horizontal spacing (limits flex grow). |
| `maxY`       | `number \| SpacerObject`         | ❌       | Max vertical spacing (limits flex grow). |
| `isInline`   | `boolean \| Breakpoints[]`       | ❌       | Renders spacer as inline element. |
| `isNotStretching` | `boolean \| Breakpoints[]`  | ❌       | Disables spacer from stretching. |
| `testId`     | `string`                         | ❌       | Cypress test selector. |

### Skeleton

| Prop         | Type               | Required | Description |
|--------------|--------------------|----------|-------------|
| `isLoading`  | `boolean`          | ✅       | Whether to show skeleton loader. |
| `width`      | `number \| Width`  | ❌       | Width of the skeleton block. |
| `height`     | `number \| Height` | ❌       | Height of the skeleton block. |
| `circle`     | `boolean`          | ❌       | Makes skeleton rounded. |
| `count`      | `number`           | ❌       | Number of skeleton blocks. |
| `group`      | `string`           | ❌       | Animation delay group ID. |
| `testId`     | `string`           | ❌       | Cypress test selector. |

### Hidden / Visible

| Prop  | Type    | Description |
|-------|---------|-------------|
| `xs`  | boolean | Hidden or visible on `xs`. |
| `sm`  | boolean | Hidden or visible on `sm`. |
| `md`  | boolean | Hidden or visible on `md`. |
| `lg`  | boolean | Hidden or visible on `lg`. |
| `xl`  | boolean | Hidden or visible on `xl`. |
| `xxl` | boolean | Hidden or visible on `xxl`. |
| `xxxl`| boolean | Hidden or visible on `xxxl`. |
| `isLoadingHtml` | boolean | Still renders HTML even if hidden. |

### ResponsiveText

| Prop    | Type   | Required | Description |
|---------|--------|----------|-------------|
| `xs`    | string | ✅       | Text for xs screen. |
| `sm`-`xxxl` | string | ❌   | Optional text per breakpoint. |