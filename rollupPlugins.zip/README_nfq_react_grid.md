# @nfq/react-grid

<div id="top"></div>

<p align="center">
  <img src="https://img.shields.io/npm/v/@nfq/react-grid.svg" alt="npm version" />
  <img src="https://img.shields.io/npm/dm/@nfq/react-grid.svg" alt="npm downloads" />
  <img src="https://img.shields.io/bundlephobia/min/@nfq/react-grid" alt="BundlePhobia size" />
  <img src="https://img.shields.io/github/issues/nfqde/nfq-react-grid.svg" alt="GitHub issues" />
  <img src="https://img.shields.io/github/contributors/nfqde/nfq-react-grid.svg" alt="Contributors" />
  <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License" />
</p>

<p align="center">
  <a href="https://github.com/nfqde/nfq-react-grid/actions/workflows/eslint.yml"><img src="https://github.com/nfqde/nfq-react-grid/actions/workflows/eslint.yml/badge.svg" alt="ESLint" /></a>
  <a href="https://github.com/nfqde/nfq-react-grid/actions/workflows/horusec.yml"><img src="https://github.com/nfqde/nfq-react-grid/actions/workflows/horusec.yml/badge.svg" alt="Horusec" /></a>
  <a href="https://github.com/nfqde/nfq-react-grid/actions/workflows/cypress.yml"><img src="https://github.com/nfqde/nfq-react-grid/actions/workflows/cypress.yml/badge.svg" alt="Cypress Tests" /></a>
</p>

---

## @nfq/react-grid

A powerful, theme-free, responsive grid system for React powered by `@emotion/react`.  
Built on modern CSS variables, mobile-first principles, and full TypeScript support.

Inspired by [react-awesome-styled-grid](https://github.com/santosfrancisco/react-awesome-styled-grid), re-engineered for real-world production use.

---

## 🚀 Features

- ⚛️ No dependency on theme providers – works out of the box with CSS custom properties.
- 🧱 Responsive grid layout: `Container`, `Row`, `Col`, `Spacer`
- 🧩 Extra helpers: `Skeleton`, `Hidden`, `Visible`, `ResponsiveText`
- 🧠 Hooks and utilities: `useScreenSize`, `spacing`, `media()`
- 🔍 Built-in debug layer via `Ctrl + D`
- 🎨 Fully configurable skeleton animations and design tokens
- 🧪 Test-friendly via `testId` props

---

## 📦 Installation

```bash
npm install @nfq/react-grid @emotion/react @emotion/styled
```

### Required Peer Dependencies

- `react >= 17`
- `@emotion/react >= 11`
- `@emotion/styled >= 11`

---

## ⚡ Quick Usage

```tsx
import { Container, Row, Col, Spacer } from '@nfq/react-grid';

function App() {
  return (
    <Container>
      <Row>
        <Col xs={6}>Left</Col>
        <Spacer x={1} />
        <Col xs={6}>Right</Col>
      </Row>
    </Container>
  );
}
```

> Wrap your app in `<ScreenSizeProvider>` if you use `Skeleton`, `useScreenSize`, or responsive visibility features.

---

## 📐 Breakpoint-based Layout

All layout props (like `xs`, `sm`, `md`, etc.) follow a mobile-first approach. Missing values cascade upwards.

```tsx
<Col xs={6} md={3} xl="auto" />
```

---

## 🧠 Hook-Based Utilities

```tsx
const screenSize = useScreenSize(); // 'xs', 'md', 'xl' etc.
const spacingValue = spacing(2);   // => calc(var(--nfq-grid-base-spacing) * 2)
```

---

## 🧰 Configuration (Optional)

You can override default grid settings by providing a config object to the `nfqgrid` CSS variable system internally. No ThemeProvider needed.

Default configuration includes:

- Breakpoints (`xs` to `xxl`)
- Columns per breakpoint
- Gaps, container padding
- Skeleton variants and debug colors

See `/src/config/default.ts` for all default values.

---

## 🧪 Debug Tools

- Toggle grid debugging: `Ctrl + D` (dev only)
- Display current screen size: `<ScreenBadge />`

---

## 📄 License

MIT © [NFQ Technologies](https://www.nfq.de/)