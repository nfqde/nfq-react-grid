# @nfq/react-grid

<div id="top"></div>

<p align="center">
  <img src="https://img.shields.io/npm/v/@nfq/react-grid.svg" alt="npm version" />
  <img src="https://img.shields.io/npm/dm/@nfq/react-grid.svg" alt="npm downloads" />
  <img src="https://img.shields.io/bundlephobia/min/@nfq/react-grid" alt="BundlePhobia size" />
  <img src="https://img.shields.io/github/issues/nfqde/nfq-react-grid.svg" alt="GitHub issues" />
  <img src="https://img.shields.io/github/contributors/nfqde/nfq-react-grid.svg" alt="Contributors" />
  <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License" />
</p>

<p align="center">
  <a href="https://github.com/nfqde/nfq-react-grid/actions/workflows/eslint.yml"><img src="https://github.com/nfqde/nfq-react-grid/actions/workflows/eslint.yml/badge.svg" alt="ESLint" /></a>
  <a href="https://github.com/nfqde/nfq-react-grid/actions/workflows/horusec.yml"><img src="https://github.com/nfqde/nfq-react-grid/actions/workflows/horusec.yml/badge.svg" alt="Horusec" /></a>
  <a href="https://github.com/nfqde/nfq-react-grid/actions/workflows/cypress.yml"><img src="https://github.com/nfqde/nfq-react-grid/actions/workflows/cypress.yml/badge.svg" alt="Cypress Tests" /></a>
</p>

---

## @nfq/react-grid

A powerful, theme-free, responsive grid system for React powered by `@emotion/react`.  
Built on modern CSS variables, mobile-first principles, and full TypeScript support.

Inspired by [react-awesome-styled-grid](https://github.com/santosfrancisco/react-awesome-styled-grid), re-engineered for real-world production use.

---

## 🚀 Features

- ⚛️ Emotion-based (`@emotion/react`, `@emotion/styled`)
- 🧱 Responsive grid layout: `Container`, `Row`, `Col`, `Spacer`
- 🧩 Components: `Skeleton`, `Hidden`, `Visible`, `ResponsiveText`
- 🧠 Utilities: `spacing()`, `media()`, `getScreenSize()`
- 🔍 Debug mode & screen indicators
- 🎛 Configurable via module declaration — fully typed
- 💅 All powered via CSS variables, no `ThemeProvider` needed

---

## 📦 Installation

```bash
npm install @nfq/react-grid @emotion/react @emotion/styled
```

### Peer Dependencies

- `react >= 17`
- `@emotion/react >= 11`
- `@emotion/styled >= 11`

---

## ⚡ Quick Start

```tsx
import { Container, Row, Col, Spacer } from '@nfq/react-grid';

function App() {
  return (
    <Container>
      <Row>
        <Col xs={6}>Left</Col>
        <Spacer x={1} />
        <Col xs={6}>Right</Col>
      </Row>
    </Container>
  );
}
```

> Wrap your app in `<ScreenSizeProvider>` if you use `Skeleton`, `useScreenSize`, or responsive visibility features.

---

## 🎛 Configuration

You can customize the grid by extending the default config with your own breakpoints or styles:

```ts
// grid.d.ts
declare module '@nfq/react-grid' {
    export interface UserConfig {
        Breakpoints: 'lg' | 'md' | 'sm' | 'xl' | 'xs' | 'xxl' | 'xxxl';
        Config: typeof configType;
    }
}
```

```ts
// config.ts
export const { configType, globalCss: globalGridCss } = createConfig(
  ['xs', 'sm', 'md', 'lg', 'xl', 'xxl', 'xxxl'],
  {
    baseSpacing: 0.4,
    breakpoints: { xxxl: 1920 },
    container: {
      xs: 'fluid',
      sm: 'fluid',
      md: 'fluid',
      lg: 'fluid',
      xl: 1140,
      xxl: 1140,
      xxxl: 1920,
    },
    skeleton: {
      dark: {
        animation: { delay: 0.02, direction: 'reverse', duration: 1.8 },
        borderRadius: 0.4,
        colors: {
          base: 'rgba(0, 0, 102, 0.3)',
          baseHighlight: 'rgba(0, 0, 102, 0)',
          highlight: 'rgba(0, 0, 102, 0.3)',
        },
      },
      light: {
        animation: { delay: 0.02, direction: 'normal', duration: 1.8 },
        borderRadius: 0.4,
        colors: {
          base: 'rgba(255, 255, 255, 0.3)',
          baseHighlight: 'rgba(0, 0, 102, 0)',
          highlight: 'rgba(0, 0, 102, 0.3)',
        },
      },
    },
  }
);
```

### Global Style Usage

```ts
export const globals = css`
  ${globalCss}
  ${globalGridCss}

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-size: 10px;
  }

  html, body {
    margin: 0;
    padding: 0;
    min-height: 100%;
    scroll-behavior: smooth;
  }

  #__next {
    min-height: 100%;
  }
`;
```

---

## 📐 Utilities

### `spacing(space: number): string`

Utility to calculate spacing based on the configured `baseSpacing` value.

```tsx
const StyledBox = styled.div`
  padding: ${spacing(2)}; // => calc(var(--nfq-grid-base-spacing) * 2)
`;
```

Used inside `@emotion/styled` or `css` templates.

### `media(breakpoint: Breakpoints): string`

```tsx
${media('md')} {
  padding-top: 4rem;
}
```

Creates a media query starting at the given breakpoint.

### `mediaBetween(min: Breakpoints, max: Breakpoints): string`

```tsx
${mediaBetween('sm', 'lg')} {
  padding-top: 2rem;
}
```

Media query between two breakpoints.

### `getScreenSize(): Breakpoints`

Returns the currently active breakpoint from CSS custom properties.

---

## 🔍 Debugging

Use the `ScreenBadge` component to always show the active screen class:

```tsx
<ScreenSizeProvider>
  <ScreenBadge />
  <App />
</ScreenSizeProvider>
```

Toggle debug visuals with `Ctrl + D` in development mode to visualize the grid, paddings, and containers.

---

## 📄 License

MIT © [NFQ Technologies](https://www.nfq.de/)