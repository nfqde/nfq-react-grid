export const Viewports = {
    lg: [1000, 500],
    md: [770, 500],
    sm: [580, 500],
    xl: [1500, 500],
    xs: [400, 500],
    xxl: [2000, 500]
};