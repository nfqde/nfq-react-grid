import type { BreakpointCache } from '../sharedTypes/breakpointTypes';
declare const configCache: Map<"breakpointConfig", BreakpointCache>;
export { configCache };
