export * from './ResponsiveText';
