import type { FlexGap, GapObject } from '../../sharedTypes/componentTypes';
interface CalcGapProps {
    $hasNoGap?: FlexGap | GapObject;
}
/**
 * Calculates the flex gap CSS string for a given theme and gap configuration.
 *
 * The function calculates the gap based on the `columnGap` and `rowGap` properties of the theme and the gap
 * configuration provided. It generates CSS rules for each screen size defined in the theme, based on the gap
 * configuration, and returns a string for each size.
 *
 * @param props           The styled-components props object.
 * @param props.$hasNoGap The gap configuration object or boolean value that specifies if the gap should be disabled.
 * @param props.theme     The styled-components theme.
 *
 * @returns An array that contains the flex gap css strings for each screen size for the given configuration.
 */
export declare const calcGap: ({ $hasNoGap }: CalcGapProps) => (string | null)[];
export {};
