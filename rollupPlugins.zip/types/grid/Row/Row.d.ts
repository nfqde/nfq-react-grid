import type { ElementType } from 'react';
import React from 'react';
import type { Breakpoints } from '../../sharedTypes/breakpointTypes';
import type { AlignObject, DirectionObject, FlexAlign, FlexDirection, FlexGap, FlexJustify, GapObject, JustifyObject, MouseEventHandler, OrderObject } from '../../sharedTypes/componentTypes';
interface ComponentProps {
    /** Defines the content alignment of the row. It takes a `AlignObject` or a `FlexAlign` type value. Its direction is dependent on the `direction` prop. */
    align?: AlignObject | FlexAlign;
    /** Sets the html element type of the row. If you overwrite its styles with styled() it has to be forwardedAs. */
    as?: ElementType;
    /** Classname property to overwrite styles with styled(). */
    className?: string;
    /** Sets the direction the row children should render ('row' or 'column'). It takes a `DirectionObject` or a `FlexDirection` type value. */
    direction?: DirectionObject | FlexDirection;
    /** Removes the gap between columns in the grid. Can be also no-column and no-row which deactivates the gap for either direction. It takes a `FlexGap` or a `GapObject` type value. */
    hasNoGap?: FlexGap | GapObject;
    /** Defines if the row will wrap or not. It takes an array of `Breakpoints` or a `boolean` value. */
    hasNoWrap?: Breakpoints[] | boolean;
    /** Reverses the direction of the row. It takes an array of `Breakpoints` or a `boolean` value. */
    isReverse?: Breakpoints[] | boolean;
    /** Defines the content justification of the row. It takes a `FlexJustify` or a `JustifyObject` type value. Its direction is dependent on the `direction` prop. */
    justify?: FlexJustify | JustifyObject;
    /** Sets the order this row should be in. It takes an `OrderObject` or a `number` value. */
    order?: OrderObject | number;
    /** TestId for cypress testing. */
    testId?: string;
}
/**
 * Row component that creates a grid row.
 *
 * This component creates a row within a grid system. It can accept multiple props to configure the row's layout.
 *
 * @param props           The props for the Row component.
 * @param props.align     Defines the content alignment of the row. It takes a `AlignObject` or a `FlexAlign` type value. Its direction is dependent on the `direction` prop.
 * @param props.as        Sets the html element type of the row. If you overwrite its styles with styled() it has to be forwardedAs.
 * @param props.children  The child elements to be rendered within the row.
 * @param props.className Classname property to overwrite styles with styled().
 * @param props.direction Sets the direction the row children should render ('row' or 'column'). It takes a `DirectionObject` or a `FlexDirection` type value.
 * @param props.hasNoGap  Removes the gap between columns in the grid. Can be also no-column and no-row which deactivates the gap for either direction. It takes a `FlexGap` or a `GapObject` type value.
 * @param props.hasNoWrap Defines if the row will wrap or not. It takes an array of `Breakpoints` or a `boolean` value.
 * @param props.isReverse Reverses the direction of the row. It takes an array of `Breakpoints` or a `boolean` value.
 * @param props.justify   Defines the content justification of the row. It takes a `FlexJustify` or a `JustifyObject` type value. Its direction is dependent on the `direction` prop.
 * @param props.order     Sets the order this row should be in. It takes an `OrderObject` or a `number` value.
 * @param props.testId    TestId for cypress testing.
 *
 * @returns The Row component.
 * @example
 * ```tsx
 * import {Col, Row} from '@nfq/react-grid';
 *
 * const App = () => (
 *     <Row hasNoGap>
 *         <Col>
 *             <div>Column 1</div>
 *         </Col>
 *         <Col>
 *             <div>Column 2</div>
 *         </Col>
 *     </Row>
 * );
 * ```
 */
declare const Row: React.ForwardRefExoticComponent<ComponentProps & MouseEventHandler & {
    children?: React.ReactNode;
} & React.RefAttributes<HTMLDivElement>>;
export { Row };
