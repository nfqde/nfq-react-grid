import type { SkeletonStore } from '../../sharedTypes/componentTypes';
type callbackType = () => void;
/**
 * A custom React hook that creates and manages a skeleton store.
 * This store keeps track of registered skeleton components and their states.
 * The hook provides functions to register, unregister, and subscribe to changes in the skeleton store.
 * It is designed to manage the state of skeleton components across the application, ensuring consistent
 * behavior and updates.
 *
 * @returns An object containing methods to interact with the skeleton store:
 * - `get`: A function to retrieve the current state of the store.
 * - `register`: A function to register a new skeleton component in the store.
 * - `subscribe`: A function to subscribe to changes in the store.
 * - `unregister`: A function to unregister a skeleton component from the store.
 *
 * @example
 * ```tsx
 * const { get, register, subscribe, unregister } = useSkeletonStore();
 * ```
 */
export declare const useSkeletonStore: () => {
    get: () => SkeletonStore;
    register: (group: string, value: {
        count: number;
        id: string;
    }) => void;
    subscribe: (callback: callbackType) => () => boolean;
    unregister: (group: string, value: string) => void;
};
export {};
