/**
 * Initializes and provides screen size and skeleton store state for context usage.
 * This hook is used internally by the `ScreenSizeProvider` component in the `@nfq/react-grid` system
 * to manage and expose responsive breakpoint information and the global `skeletonStore`. It calculates
 * the current screen size by reading the CSS custom property `--nfq-grid-screen-size`, and updates this
 * state reactively on window resize events.
 * The default screen size is initialized to the last breakpoint in the configured `breakpointOrder`.
 * It uses a `useReducer` for stable state transitions and ensures the value updates only when it changes.
 *
 * @returns An object containing the current `screenSize` and the global `skeletonStore` instance.
 *
 * @example
 * ```tsx
 * const { screenSize, skeletonStore } = useScreenSizeProvider();
 *
 * console.log(screenSize); // 'md', 'lg', etc.
 * ```
 */
export declare const useScreenSizeProvider: () => {
    screenSize: "lg" | "md" | "sm" | "xl" | "xs" | "xxl";
    skeletonStore: {
        get: () => import("../../sharedTypes/componentTypes").SkeletonStore;
        register: (group: string, value: {
            count: number;
            id: string;
        }) => void;
        subscribe: (callback: () => void) => () => boolean;
        unregister: (group: string, value: string) => void;
    };
};
