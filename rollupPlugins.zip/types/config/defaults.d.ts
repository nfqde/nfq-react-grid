export declare const VAR_PREFIX = "nfq-grid";
export declare const defaultBaseSpacing = 0.5;
export declare const defaultBreakpoints: {
    lg: number;
    md: number;
    sm: number;
    xl: number;
    xs: number;
    xxl: number;
};
export declare const defaultColumnGap = 20;
export declare const defaultColumns = 12;
export declare const defaultContainerPadding = 10;
export declare const defaultDebug: {
    col: {
        background: string;
        outline: string;
        padding: string;
    };
    container: {
        background: string;
        outline: string;
        padding: string;
    };
    row: {
        background: string;
        outline: string;
        padding: string;
    };
    spacer: {
        background: string;
        outline: string;
        padding: string;
    };
};
export declare const defaultMediaQuery = "only screen";
export declare const defaultSkeleton: {
    dark: {
        animation: {
            delay: number;
            direction: string;
            duration: number;
        };
        borderRadius: number;
        colors: {
            base: string;
            baseHighlight: string;
            highlight: string;
        };
    };
    light: {
        animation: {
            delay: number;
            direction: string;
            duration: number;
        };
        borderRadius: number;
        colors: {
            base: string;
            baseHighlight: string;
            highlight: string;
        };
    };
};
export declare const defaultSkeletonDefault: "dark";
